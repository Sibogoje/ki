<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate to Kwakha Indvodza</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        .form-label {
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container mt-2" style="padding-bottom: 30px">
    <!--<h1 class="text-center">Donate to Kwakha Indvodza</h1>-->
    <p class="text-center">Your support makes a difference. Please complete the form below to make your donation.</p>
    <form id="donationForm" action="process_donation.php" method="POST">
        <!-- Donor Information -->
        <div class="mb-3">
            <label for="donorName" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="donorName" name="donor_name" placeholder="Enter your full name" required>
        </div>
        <div class="mb-3">
            <label for="donorPhone" class="form-label">Phone Number</label>
            <input type="tel" class="form-control" id="donorPhone" name="donor_phone" placeholder="Enter your phone number" required>
        </div>
        <div class="mb-3">
            <label for="donorEmail" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="donorEmail" name="donor_email" placeholder="Enter your email address">
        </div>

        <!-- Donation Details -->
        <div class="mb-3">
            <label for="donationAmount" class="form-label">Donation Amount (SZL)</label>
            <input type="number" step="0.01" class="form-control" id="donationAmount" name="donation_amount" placeholder="Enter the donation amount" required>
        </div>
        <div class="mb-3">
            <label for="otherDonations" class="form-label">Other Donations (Optional)</label>
            <textarea class="form-control" id="otherDonations" name="other_donations" placeholder="Mention other donations or comments"></textarea>
        </div>

        <!-- Pledge and Reminder Options -->
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="isPledge" name="is_pledge">
            <label for="isPledge" class="form-check-label">This is a pledge</label>
        </div>
        <div class="mb-3">
            <label for="pledgeDate" class="form-label">Pledge Date</label>
            <input type="date" class="form-control" id="pledgeDate" name="pledge_date" disabled>
        </div>
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="reminderCheck" name="reminder_check">
            <label for="reminderCheck" class="form-check-label">Send me a reminder</label>
        </div>
        <div class="mb-3">
            <label for="reminderDate" class="form-label">Reminder Date</label>
            <input type="date" class="form-control" id="reminderDate" name="reminder_date" disabled>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary w-100">Submit Donation</button>
    </form>
</div>

<script>
    document.getElementById('isPledge').addEventListener('change', function () {
        document.getElementById('pledgeDate').disabled = !this.checked;
    });

    document.getElementById('reminderCheck').addEventListener('change', function () {
        document.getElementById('reminderDate').disabled = !this.checked;
    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
