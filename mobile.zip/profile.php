<?php
// Include the database connection file
include '../con.php';
$conn = new Con();
$db = $conn->connect();
// Start a session
session_start();

$phone = $_GET['phone'];

if ($phone == ""){
    
$query = "SELECT *
          FROM users 
          WHERE user_id = ?";
$stmt = $db->prepare($query);
$stmt->bind_param('i', $_SESSION['uid']);
$stmt->execute();
$userData = $stmt->get_result()->fetch_assoc();
//$_SESSION['client_user_id'] = $userData['user_id'];

echo "uguyyuy";
    
}else{
    
$query = "SELECT *
          FROM users 
          WHERE phone_number = ?";
$stmt = $db->prepare($query);
$stmt->bind_param('i', $phone);
$stmt->execute();
$userData = $stmt->get_result()->fetch_assoc();
$_SESSION['client_user_id'] = $userData['user_id'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Profile</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Content Start -->
        <div class="content">

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

            <!-- Blank Start -->
<?php
// Fetch the user data for the profile


// $query = "SELECT *
//           FROM users 
//           WHERE phone_number = ?";
// $stmt = $db->prepare($query);
// $stmt->bind_param('i', $phone);
// $stmt->execute();
// $userData = $stmt->get_result()->fetch_assoc();

// $_SESSION['client_user_id'] = $userData['user_id'];
?>

<div class="container-fluid pt-2 px-2">
    <div class="row bg-light rounded align-items-center justify-content-center mx-0">
        <div class="col-md-12 mb-4" style="padding: 5px;">
            <div class="card shadow-sm">
                <div class="card-header  text-white">
                    
                </div>
                <div class="card-body">
                    <!-- Basic Information -->
                    <h5 class="mb-3">Basic Information</h5>
                    <table class="table table-borderless">
                        <tr>
                            <th>Name:</th>
                            <td><?php echo htmlspecialchars($userData['name'] . ' ' . $userData['surname']); ?></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo htmlspecialchars($userData['email']); ?></td>
                        </tr>
                        <tr>
                            <th>Phone Number:</th>
                            <td><?php echo htmlspecialchars($userData['phone_number']); ?></td>
                        </tr>
                        <tr>
                            <th>Age:</th>
                            <td><?php echo htmlspecialchars($userData['age']); ?></td>
                        </tr>
                        <tr>
                            <th>Gender:</th>
                            <td><?php echo htmlspecialchars($userData['gender']); ?></td>
                        </tr>
                        <tr>
                            <th>Marital Status:</th>
                            <td><?php echo htmlspecialchars($userData['marital']); ?></td>
                        </tr>
                        
                    </table>

                    <!-- Additional Information -->
                    <h5 class="mt-4 mb-3">Additional Information</h5>
                    <table class="table table-borderless">
                        <tr>
                            <th>Orphan Status:</th>
                            <td><?php echo htmlspecialchars($userData['orphan']); ?></td>
                        </tr>
                         <tr>
                            <th>Highest Level of Education:</th>
                            <td><?php echo htmlspecialchars($userData['education']); ?></td>
                        </tr>
                         <tr>
                            <th>Disability Status:</th>
                            <td><?php echo htmlspecialchars($userData['disability']); ?></td>
                        </tr>
                        <tr>
                            <th>Region:</th>
                            <td><?php echo htmlspecialchars($userData['region']); ?></td>
                        </tr>
                        <tr>
                            <th>Constituency:</th>
                            <td><?php echo htmlspecialchars($userData['constituency']); ?></td>
                        </tr>
                          <tr>
                            <th>Community:</th>
                            <td><?php echo htmlspecialchars($userData['community']); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="card-footer text-end">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profile</button>
</div>

            </div>
        </div>
    </div>
</div>


<!-- Edit Profile Modal -->
<div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="update_profile.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
        <div class="modal-body">
          <div class="row mb-3">
        <div class="col-md-6">
            <label for="name" class="form-label">First Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($userData['name']); ?>" required>
        </div>
        <div class="col-md-6">
            <label for="surname" class="form-label">Last Name</label>
            <input type="text" class="form-control" id="surname" name="surname" value="<?php echo htmlspecialchars($userData['surname']); ?>" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" required>
        </div>
        <div class="col-md-6">
            <label for="phone_number" class="form-label">Phone Number</label>
            <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($userData['phone_number']); ?>" required>
        </div>
    </div>
    <div class="row mb-3">
<div class="col-md-6">
    <label for="age" class="form-label">Age</label>
    <select class="form-control" id="age" name="age">
        <option value="">Select Age Range</option>
        <?php

        // Fetch age ranges from the table
        $sql = "SELECT age_range FROM age_ranges";
        $result = $db->query($sql);

        if ($result->num_rows > 0) {
            // Loop through the results to populate the dropdown
            while ($row = $result->fetch_assoc()) {
                $ageRange = $row['age_range'];
                $selected = ($userData['age'] == $ageRange) ? 'selected' : '';
                echo "<option value=\"$ageRange\" $selected>$ageRange</option>";
            }
        } else {
            echo "<option value=\"\">No Age ranges available</option>";
        }

        // Close the connection
        $db->close();
        ?>
    </select>
</div>

        <div class="col-md-6">
            <label for="gender" class="form-label">Gender</label>
            <select class="form-control" id="gender" name="gender">
                <option value="Male" <?php if ($userData['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                <option value="Female" <?php if ($userData['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                <option value="Other" <?php if ($userData['gender'] == 'Other') echo 'selected'; ?>>Other</option>
            </select>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="marital" class="form-label">Marital Status</label>
            <input type="text" class="form-control" id="marital" name="marital" value="<?php echo htmlspecialchars($userData['marital']); ?>">
        </div>
        <div class="col-md-6">
            <label for="orphan" class="form-label">Orphan Status</label>
            <select class="form-control" id="orphan" name="orphan">
                <option value="Yes" <?php if ($userData['orphan'] == 'Yes') echo 'selected'; ?>>Yes</option>
                <option value="No" <?php if ($userData['orphan'] == 'No') echo 'selected'; ?>>No</option>
            </select>
        </div>
    </div>
    <h5 class="mt-4 mb-3">Additional Information</h5>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="education" class="form-label">Highest Level of Education</label>
            <input type="text" class="form-control" id="education" name="education" value="<?php echo htmlspecialchars($userData['education']); ?>">
        </div>
        <div class="col-md-6">
            <label for="disability" class="form-label">Disability Status</label>
            <input type="text" class="form-control" id="disability" name="disability" value="<?php echo htmlspecialchars($userData['disability']); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="region" class="form-label">Region</label>
            <select class="form-control" id="region" name="region">
                <option value="Hhohho" <?php if ($userData['region'] == 'Hhohho') echo 'selected'; ?>>Hhohho</option>
                <option value="Manzini" <?php if ($userData['region'] == 'Manzini') echo 'selected'; ?>>Manzini</option>
                <option value="Shiselweni" <?php if ($userData['region'] == 'Shiselweni') echo 'selected'; ?>>Shiselweni</option>
                <option value="Lubombo" <?php if ($userData['region'] == 'Lubombo') echo 'selected'; ?>>Lubombo</option>
            </select>
        </div>
        <div class="col-md-6">
            <label for="constituency" class="form-label">Constituency</label>
            <input type="text" class="form-control" id="constituency" name="constituency" value="<?php echo htmlspecialchars($userData['constituency']); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="community" class="form-label">Community</label>
            <input type="text" class="form-control" id="community" name="community" value="<?php echo htmlspecialchars($userData['community']); ?>">
        </div>
    </div>
</div>




                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

        </div>
        <!-- Content End -->



    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>


</body>

</html>