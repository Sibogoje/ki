<?php
// Database connection
include('../con.php');
$conn = new Con();
$db = $conn->connect();

$phone = $_GET['phone'];

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Query to fetch bookings
$sql = "SELECT 
            booking_date, 
            STATUS, 
            MODE, 
            counselor_surname, 
            counselor_name, 
            cancellation_reason, 
            last_modified_at, 
            approved_by_counselor 
        FROM booking_info where user_phone_number = '$phone' ";

$result = $db->query($sql);

$bookings = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($bookings);

$db->close();
?>
