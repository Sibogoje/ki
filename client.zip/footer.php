<footer>
        <img src="../ki.png" alt="Image 1">
        <img src="../icon.png" alt="Image 2">
        <img src="../fnb.png" alt="Image 3">
</footer>